README for viterbi algorithm

The viterbi script is written in python "viterbi.py"
To run it, enter the string as a commandline without any quotes as follows:

$ python viterbi.py That is a test .

The script requires the train-data file and therefore should be kept in the same directory or the path to train-data which is hardcoded can be changed.
